return {
	"windwp/nvim-ts-autotag",
	lazy = false,
}
