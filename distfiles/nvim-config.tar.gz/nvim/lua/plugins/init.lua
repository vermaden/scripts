return {
  { "folke/neoconf.nvim", cmd = "Neoconf" },
  "folke/neodev.nvim",
}
